from django.apps import AppConfig


class DreamerConfig(AppConfig):
    name = 'Dreamer'
